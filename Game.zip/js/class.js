"use strict";
let idIndex = 1;
const players = new Array();
const gameSettings = {
    turnOwner: 0,
    level1: 5,
    level2: 10,
    level3: 15,
    limit_workers : 6,
    limit_army : 4,
    limit_warchiefs : 1,
    limit_townhalls : 2,
    limit_towers : 3,
    //skills:['Strength I','Strength II','Pathfinder','Surgery','Estates I', 'Estates'];
    skills:[
        {name:'Strength I', description:'Увеличивает силу атаки Вождя на 1'},
        {name:'Strength II', description:'Увлеичивает здоровье Вождя на 2'},
        {name:'Pathfinder', description:'Увеличивает скорость Вождя на 1'},
        {name:'Surgery', description:'Позволяет вождю лечить себя или союзников'},
        {name:'Estates I', description:'Единовременно дает 5 золота'},
        {name:'Estates II', description:'Каждый ход дает 1 золото'}]
};
class Player{
    constructor(name, num){
        this.name = name;
        this.owner = num;
        //this.color
        this.gold = 0;
        this.counts = 0
        this.level = 0;
        this.exp = 0;
        this.skills = [];
        this.count_workers = 0;
        this.count_army = 0;
        this.count_warchiefs = 0;
        this.count_townhalls = 0;
        this.count_towers = 0;
        this.faction = {
            name:'Human',
            t1:['unit','T1','Peasant','description',1,1,1,1,0,['worker'],"img/units/HumanT1.png",'Townhall'],
            t2:['unit','T2','Scout','description',1,1,2,1,1,[],"img/units/HumanT2.png",'Townhall'],
            t3:['unit','T3','Knight','description',3,1,1,1,2,[],"img/units/swordsman.png",'Tower'],
            warchief:['unit','Warchief','Lord','description',4,1,2,1,5,['cavalryStrike'],"img/units/HumanWarchief2.png",'Tower'],
            townhall:['building','Townhall','Townhall','description',5,0,0,0,5,['hire'],"img/units/citadel.png"],
            tower:['building','Tower','Tower','description',3,1,0,2,3,['hire'],"img/units/Tower.png"]
        }
    }
}

class Unit{
    constructor(arrInf, owner, action){
        this.type = arrInf[0];
        this.class = arrInf[1];
        this.name = arrInf[2];
        this.description = arrInf[3];
        this.hpMax = arrInf[4];
        this.hp = arrInf[4];
        this.attack = arrInf[5];
        this.movePoint = arrInf[6];
        this.range = arrInf[7];
        this.ability = arrInf[9];
        this.canMove = action;
        this.canAction = action;
        this.owner = owner;
        this.id = idIndex++;
        this.image = arrInf[10];
        this.out = arrInf[11]
        
    }
}

class Building{
    constructor(arrInf, owner, action){
        this.type = arrInf[0];
        this.class = arrInf[1];
        this.name = arrInf[2];
        this.description = arrInf[3];
        this.hpMax = arrInf[4];
        this.hp = arrInf[4];
        this.attack = arrInf[5];
        this.movePoint = arrInf[6];
        this.range = arrInf[7];
        this.cost = arrInf[8];
        this.ability = arrInf[9];
        this.canMove = action;
        this.canAction = action;
        this.owner = owner;
        this.id = idIndex++;
        this.image = arrInf[10];
    }
}

class Warchief{

}

let exampleUnit = {
    type: 'unit/building',
    class: 'T1/T2/T3/Warchief/Townhall/Tower',
    name: 'name)',
    description: 'example unit',
    canMove: true,
    canAction: true,
    hp: 1,
    attack: 1,
    movePoint: 1,
    range: 1,
    owner: 0


};